import { LightningElement, api } from 'lwc';
import communityBasePath from '@salesforce/community/basePath';

const LINK_TOTAL = 10;

export default class EmedHeader extends LightningElement {
    @api homeLinkUrl = null;

    // LINKS
    @api headerLinkLabel1 = null;
    @api headerLinkLabel2 = null;            
    @api headerLinkLabel3 = null;
    @api headerLinkLabel4 = null;
    @api headerLinkLabel5 = null;
    @api headerLinkLabel6 = null;
    @api headerLinkLabel7 = null;
    @api headerLinkLabel8 = null;
    @api headerLinkLabel9 = null;
    @api headerLinkLabel10 = null;

    @api headerLinkUrl1 = null;
    @api headerLinkUrl2 = null;
    @api headerLinkUrl3 = null;
    @api headerLinkUrl4 = null;
    @api headerLinkUrl5 = null;
    @api headerLinkUrl6 = null;
    @api headerLinkUrl7 = null;
    @api headerLinkUrl8 = null;
    @api headerLinkUrl9 = null;
    @api headerLinkUrl10 = null;

    get headerLinkOptions() {
        return this.getOptions();
    }
    
    getOptions() {
        const fieldName = 'linkHeaderLabel';
        const fieldValue = 'linkHeaderUrl';
        const result = [];

        for (let i = 1; i <= LINK_TOTAL; i++) {
            const label = this[`${fieldName}${i}`];
            const value = this[`${fieldValue}${i}`];
            const item = { 
                label, 
                value: this.isExternalUrl(value) ? value : communityBasePath + value
            };

            if (item.label && item.value) {
                result.push(item);
            }
        }

        return result;
    }

    isExternalUrl(url) {
        const regex = /^https?:\/\//;
        return regex.test(url);
    }

    get getCopyrightLabel() {
        return `© ${new Date().getFullYear()} eMed™ All rights reserved.`;
    }
}