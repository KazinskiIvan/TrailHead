import { LightningElement, api } from 'lwc';
import FooterImages from '@salesforce/contentAssetUrl/footerImages';

export default class CustomNavBar extends LightningElement {
    eMedLogo = FooterImages + 'pathinarchive=emed.svg';
}