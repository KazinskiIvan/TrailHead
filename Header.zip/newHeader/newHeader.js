import { LightningElement, api } from 'lwc';
import communityBasePath from '@salesforce/community/basePath';
import isGuest from '@salesforce/user/isGuest';
import getActiveCartId from '@salesforce/apex/B2BProductAddToCartController.getActiveCartId';
import getGuestOrderId from '@salesforce/apex/B2BProductAddToCartController.getGuestOrderId';
export default class NewHeader extends LightningElement {
    @api column1Title = null;
    @api column1Label1 = null;
    @api column1Url1 = null;
    @api column1Label2 = null;
    @api column1Url2 = null;
    @api column1Label3 = null;
    @api column1Url3 = null;
    @api column1Label4 = null;
    @api column1Url4 = null;
    @api column1Label5 = null;
    @api column1Url5 = null;
    @api column1Label6 = null;
    @api column1Url6 = null;
    @api column1Label7 = null;
    @api column1Url7 = null;
    @api column1Label8 = null;
    @api column1Url8 = null;
    @api column1Label9 = null;
    @api column1Url9 = null;
    @api column1Label10 = null;
    @api column1Url10 = null;

    @api login = null;
    @api shoppingCart = null;

    linkClick() {
        this.template.querySelector('.mobile').style.display = 'flex';
        this.template.querySelector('.close').style.display = 'flex';
        this.template.querySelector('.overlay').style.display = 'flex';
        this.template.querySelector('.open').style.display = 'none';
    }

    get isGuestAuth() {
        return isGuest ? true : false;
    }

    closeModal() {
        this.template.querySelector('.mobile').style.display = 'none';
        this.template.querySelector('.overlay').style.display = 'none';
        this.template.querySelector('.open').style.display = 'flex';
        this.template.querySelector('.close').style.display = 'none';
    }

    get column1Options() {
        return this.getOptions('column1Label', 'column1Url');
    }

    get showLogin() {
        return this.login;
    }

    get showShoppingCart() {
        return this.shoppingCart;
    }

    getOptions(fieldName, fieldValue) {
        const result = [];

        for (let i = 1; i <= 10; i++) {
            const label = this[`${fieldName}${i}`];
            const value = this[`${fieldValue}${i}`];
            const item = {
                label,
                value: this.isExternalUrl(value)
                    ? value
                    : communityBasePath + value
            };

            if (item.label && item.value) {
                result.push(item);
            }
        }

        return result;
    }

    isExternalUrl(url) {
        const regex = /^https?:\/\//;
        return regex.test(url);
    }

    get getCopyrightLabel() {
        return `© ${new Date().getFullYear()} eMed™ All rights reserved.`;
    }
}